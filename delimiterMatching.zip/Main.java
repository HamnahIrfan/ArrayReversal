//Hamnah and Micayla

class Main  
{
private static String[] stackArray;
private static int top;
  
public static void main(String[] args) 
  {
    String[] s = new String[] 
    {"(","(",")","(",")","(","(",")",")","(","(",")",")",")"}; 

    Main stackArray = new Main(s.length);
  
    for (int i = 0; i < s.length; i++)
      {
        if (s[i] == "(")
        {
          push(s[i]);
        }
        else 
        {
          pop();
        }
      }

    if (isEmpty())
        {
          System.out.println("Your input is balanced");
        }
        else 
        {
          System.out.println("Your input is not balanced. Probably missing a parenthesis here or there");
        }
  }

public Main(int size)
  {
    int maxSize = size;
    stackArray = new String[maxSize];
    top = -1;
  }

public static void push(String j)
  {
    stackArray[++top] = j;
  }

public static String pop()
  {
    return stackArray[top--];
  }

public static boolean isEmpty()
  {
    return (top == -1);
  }  
}