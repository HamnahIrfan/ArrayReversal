class Main 
{
  public static void main(String[] args) 
  {
   int[] myCoolArray = new int[]
   {20, 10, 30, 5, -7, 8, 10, 99}; 
   int[] myCoolArray2 = new int[]
   {0,1,15,19, 72,85,43,-7};
    int myKey = -7;
    int foundMe;
    foundMe = unsortedFetch(myCoolArray,myKey);
    foundMe = unsortedFetch(myCoolArray2,1);

    int[] myAwesomeArray = new int[20];
    myAwesomeArray[0] = 2;
    myAwesomeArray[1] = 5;
    myAwesomeArray[2] = 33;  

   unsortedInsert(myAwesomeArray, 0, 99);
    
  }
  
  public static int unsortedFetch(int[] arr, int key)
  {
    int n;
    int count = 0;
    n = arr.length;
    for (int i = 0;i<n;i++) 
        {
          count = count++;
          if(arr[i] == key)
           {
             System.out.println("you found me at: " + i);
             System.out.println("It took you " + count + " amount of steps");
              return i;
            }
         } 
    return -1;
  }
  
  public static int unsortedInsert(int[] array1, int pos, int value)
  {
    array1[pos] = value;
    for(int j = 0; j<=array1.length - 1; j++)
      {
        System.out.println(array1[j]);
      }
    
    return -1;
  }
}