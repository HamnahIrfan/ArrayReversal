//Hamnah and David

class Main 
{
  public static void main(String[] args) 
  {
    int[] myCoolArray = new int[] //create an array of choice
   {20, 10, 30, 5, -7, 8, 10, 99};

    int reversedArray = arrayReversal(myCoolArray); //use the method arrayReversal on your array. the output with be the reversed array
    
  }

 public static int arrayReversal(int[] arr) //create the method arrayReversal. all it needs to be passed is the array
  {
    //print array starting from last element
    System.out.println("Inputted Array Printed in Reverse Order:");
         for(int i=arr.length-1;i>=0;i--) //use a for loop to print the elements in reversed order
           {
             System.out.print(arr[i] + "  "); //print the elements
           }
    return -1; 
  }
}