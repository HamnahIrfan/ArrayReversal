class Main
  {
  public static void main(String[] args) 
  {
    saySomething(5);  
    System.out.println(myFact(6));
  }

  public static void saySomething(int n)
    {
      if (n==0)
      {
        System.out.println("done"); 
      }

      else 
      {
        System.out.println("I hope we don't have a final on Wednesday");
        saySomething(n-1);
        
      }
    }

    public static int myFact(int m)
    {
      if (m == 0)
      {
        return 1;
      }
      else 
      {
        return  (m) * (myFact(m-1));
      }
    }
    
}